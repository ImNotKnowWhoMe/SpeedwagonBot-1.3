import disnake
from disnake.ext import commands
import g4f

class GPTCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ask(self, ctx, *, question: str):
        """Задайте вопрос GPT-4 и получите ответ."""
        await ctx.send("Обрабатываю ваш запрос...")
        
        try:
            # Использование g4f для получения ответа
            response = g4f.ChatCompletion.create(
                model="gpt-4",
                messages=[{"role": "user", "content": question}]
            )
            await ctx.send(response)  # Ожидается, что response - это строка
        except Exception as e:
            await ctx.send(f"Произошла ошибка: {str(e)}")

def setup(bot):
    bot.add_cog(GPTCog(bot))
    print("Alternative chat cog loaded")
