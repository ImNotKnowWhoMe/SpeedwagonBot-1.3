import asyncio
import g4f
from disnake.ext import commands
import disnake

# Установка политики событийного цикла для Windows
asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


class Chat(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    trigger_word = "спидвагон"

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author == self.bot.user:
            return

        if message.content.lower().startswith(self.trigger_word):
            print("Message:", message.content)
            prompt = message.content[len(self.trigger_word):].strip()

            #await message.channel.send("Обрабатываю ваш запрос...")

            try:
                # Используйте g4f для получения ответа, убирая await
                response = g4f.ChatCompletion.create(
                    model="gpt-4",
                    messages=[
                        {"role": "user", "content": prompt}
                    ]
                )
                await message.channel.send(response)  # Здесь response - это строка

            except Exception as e:
                await message.channel.send(f"Произошла ошибка: {str(e)}")

        await self.bot.process_commands(message)


def setup(bot):
    bot.add_cog(Chat(bot))
    print("Chat cog loaded")


