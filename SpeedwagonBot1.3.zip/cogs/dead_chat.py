import disnake
from disnake.ext import commands, tasks
import asyncio
from datetime import datetime, timedelta


class DeadChatCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.last_message_time = {}  # Храним время последнего сообщения для каждого канала
        self.check_for_dead_chat.start()  # Запуск таймера при инициализации кода

    # Обработчик сообщения
    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot:
            return  # Игнорируем сообщения от ботов

        # Обновляем время последнего сообщения для канала
        self.last_message_time[message.channel.id] = disnake.utils.utcnow()

    # Фоновая задача для проверки "дед чата"
    @tasks.loop(minutes=1)
    async def check_for_dead_chat(self):
        now = disnake.utils.utcnow()

        # Проверяем каналы, если прошло 3 часа с последнего сообщения
        for channel_id, last_time in list(self.last_message_time.items()):
            if (now - last_time).total_seconds() >= 1 * 60 * 60:  # 3 часа
                channel = self.bot.get_channel(channel_id)

                if channel:
                    try:
                        # Ждем сообщение "дед чат" или "dead chat"
                        def check(msg):
                            return msg.channel.id == channel_id and msg.content.lower() in ["дед чат", "dead chat", "чат умер", "чат сдох", "актив умер", "актив сдох"]

                        msg = await self.bot.wait_for('message', check=check)
                        await channel.send("Согласен")
                    except asyncio.TimeoutError:
                        pass

                # Убираем канал из слежки после завершения
                del self.last_message_time[channel_id]

    # Остановка фоновой задачи при завершении работы кода
    @check_for_dead_chat.before_loop
    async def before_check_for_dead_chat(self):
        print("Dead_chat_cog waiting for start...")
        await self.bot.wait_until_ready()

    @commands.Cog.listener()
    async def on_ready(self):
        print(f"Cog {self.__class__.__name__} loaded!")


# Функция для добавления кода в бота
def setup(bot: commands.Bot):
    bot.add_cog(DeadChatCog(bot))