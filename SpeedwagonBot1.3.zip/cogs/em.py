import disnake
from disnake.ext import commands

class AutoReact(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.target_user_id = 1286369254836539483  # ID пользователя, под чьими сообщениями будет ставиться эмодзи
        self.emoji_name = "huhumba"  # Название эмодзи на сервере

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        # Проверяем, что сообщение:
        # 1. Не от самого бота
        # 2. Принадлежит целевому пользователю
        # 3. Эмодзи есть на сервере
        if message.author.id == self.target_user_id and not message.author.bot:
            guild = message.guild
            if guild is None:
                return

            # Ищем эмодзи на сервере по названию
            emoji = disnake.utils.get(guild.emojis, name=self.emoji_name)
            if emoji:
                try:
                    await message.add_reaction(emoji)
                except disnake.Forbidden:
                    print("У бота нет прав на добавление реакций.")
                except disnake.HTTPException:
                    print("Не удалось добавить реакцию из-за ошибки сети.")

# Установка коги
def setup(bot: commands.Bot):
    bot.add_cog(AutoReact(bot))
