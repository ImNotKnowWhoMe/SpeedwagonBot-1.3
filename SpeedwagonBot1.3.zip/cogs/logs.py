import disnake
from disnake.ext import commands

class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_remove(self, member: disnake.Member):
        print(f"{member.name} left the server")  # Вывод в консоль для отладки
        channel_id = 1314589897595682826  # ID канала
        channel = self.bot.get_channel(channel_id)
        if channel:
            await channel.send(f"Участник {member.name} покинул нас... Ну и хрен с ним!")
        else:
            print(f"Канал с ID {channel_id} не найден.")  # Отладочное сообщение, если канал не найден

def setup(bot):
    bot.add_cog(Logs(bot))
    print("Logs cog loaded")
