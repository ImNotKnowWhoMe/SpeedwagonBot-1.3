import disnake
from disnake.ext import commands
import datetime
#import discord
import time
#from main import load_muted_user_ids

from disnake.ext.commands.core import command


def load_muted_user_ids():
    muted_user_ids = set()
    try:
        with open("ultra_muted.txt", "r") as file:
            for line in file:
                line = line.strip()  # Удаляем пробелы и символы новой строки
                if line.isdigit():  # Проверяем, что строка является числом
                    muted_user_ids.add(int(line))
    except FileNotFoundError:
        pass
    return muted_user_ids


class Moderation(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        self.muted_user_ids = load_muted_user_ids(
        )  # Загружаем данные при инициализации

    @commands.command()
    @commands.is_owner()
    async def ultramute(self, ctx, member: disnake.Member):
        user_id = member.id

        with open("ultra_muted.txt", "a") as file:
            file.write(f"{user_id}\n")

        # Обновляем список ID
        self.muted_user_ids = load_muted_user_ids()

        await ctx.send(
            f"ID пользователя {member.name} ({user_id}) был ультразамучен<:pizda_tebe:1247390724715053136>."
        )

    @commands.command()
    @commands.is_owner()
    async def remove_ultramute(self, ctx, member: disnake.Member):
        muted_user_ids = load_muted_user_ids()

        user_id = member.id  # Получаем ID пользователя из объекта Member

        # Отладочные сообщения
        print(f"Загруженные ID: {muted_user_ids}")
        print(f"ID пользователя для удаления: {user_id}")

        if user_id in muted_user_ids:
            muted_user_ids.remove(user_id)
            # Сохранение изменений сразу внутри команды
            with open("ultra_muted.txt", "w") as file:
                for uid in muted_user_ids:
                    file.write(f"{uid}\n")
            # Обновляем список ID
            self.muted_user_ids = load_muted_user_ids()

            await ctx.send(f"ID {user_id} был удалён из списка ультрамута.")
        else:
            await ctx.send(f"ID {user_id} не найден в списке ультрамута.")

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        if message.author.id in self.muted_user_ids:
            await message.delete()
            return

        #await self.bot.process_commands(message)

    @commands.slash_command(name='mute')
    @commands.has_any_role(1123765409062060093, 1311154946351038534)
    async def mute(self, interaction, member: disnake.Member, time: str,
                   reason: str):
        until_time = datetime.datetime.now() + datetime.timedelta(
            minutes=int(time))
        await member.timeout(reason=reason, until=until_time)
        await interaction.response.send_message(embed=disnake.Embed(
            title=
            f"{member.name} был замучен администратором/модератором по причине {reason}",
            description=f"До: {until_time}",
            color=disnake.Color.green()))
        print(f"Received mute command for {member.name}")

    @commands.slash_command(name="erase")
    @commands.has_any_role(1123765409062060093, 1311154946351038534)
    async def erase(self, interaction, amount: int):
        await interaction.response.send_message(
            f"Erased {amount} messages. [⠀](https://tenor.com/view/scrape-okuyasu-nijimura-za-hando-the-hand-jojo-gif-14165071)"
        )
        time.sleep(2)
        await interaction.channel.purge(limit=amount + 1)

    @commands.slash_command(name="ban")
    @commands.has_any_role(1123765409062060093, 1311154946351038534)
    async def ban(self, interaction, user: disnake.User, reason: str):
        await interaction.guild.ban(user, reason=reason)
        await interaction.response.send_message(
            f"{user} был забанен по причине {reason}")

    @commands.slash_command(name="unban")
    @commands.has_any_role(1123765409062060093, 1311154946351038534)
    async def unban(self, interaction, user: disnake.User):
        await interaction.guild.unban(user)
        await interaction.response.send_message(
            f"{user} только что был разбанен")


def setup(bot):
    bot.add_cog(Moderation(bot))
    print('Moderation Cog Loaded')
