import disnake
from disnake.ext import commands
import asyncio

class TimeStop(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # ID пользователя, чьи сообщения не будут удаляться
        self.exempt_user_id = 746723648760578178  # Замените на ID нужного пользователя
        # ID ролей, которые разрешают использовать эту функцию
        self.required_role_ids = [1123765409062060093, 1311154946351038534]  # Укажите ID обеих ролей

    # Слова для срабатывания триггера
    trigger_phrases = ["za warudo", "toki wo tomare", "star platinum the world"]

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        # Игнорируем сообщения бота
        if message.author.bot:
            return

        # Проверка на наличие хотя бы одной из двух ролей у пользователя
        if not any(role.id in self.required_role_ids for role in message.author.roles):
            return  # Если пользователь не имеет нужных ролей, ничего не делаем

        # Проверяем, содержит ли сообщение одну из триггерных фраз
        if any(phrase in message.content.lower() for phrase in self.trigger_phrases):
            # Отправляем сообщение "Время остановлено"
            print("time stopped")
            await message.channel.send("Время остановлено на 5 секунд [⠀](https://tenor.com/view/dio-the-world-power-charge-gif-7228945120027401562)")

            # Удаляем последующие сообщения в течение 10 секунд
            def check(m):
                # Проверяем, что это не сообщение бота, не сообщение автора и не сообщение определённого пользователя
                return (
                    m.channel == message.channel
                    and m.id != message.id  # Игнорируем сообщение с триггером
                    and m.author.id != message.author.id  # Игнорируем сообщения автора
                    and m.author.id != self.exempt_user_id  # Игнорируем сообщения определённого пользователя
                )

            try:
                while True:
                    msg = await self.bot.wait_for('message', timeout=5.0, check=check)
                    await msg.delete()
            except asyncio.TimeoutError:
                pass

# Функция для подключения кога
def setup(bot):
    bot.add_cog(TimeStop(bot))
    print("Zewarudo cog loaded")

