import disnake
from disnake.ext import commands
import os
import config

intents = disnake.Intents.default()
intents.message_content = True  # Если нужны сообщения
intents.members = True
bot = commands.Bot(command_prefix="$",
                   intents=intents,
                   owner_ids=config.owner_ids)


@bot.event
async def on_ready():
    print("SpeedwagonBot 1.3 is ready!")


@bot.slash_command()
async def help(self, interaction):
    embed = disnake.Embed(title="SpeedwagonBot 1.2",
                          description="by Marshall131",
                          color=disnake.Color.yellow())
    embed.add_field(name="Commands:", value=" ", inline=False)
    embed.add_field(name="Префикс:", value="$ и /", inline=False)
    embed.add_field(name="/poshel_nahui",
                    value="эту команду не использовать >:(",
                    inline=False)
    embed.add_field(
        name="$status",
        value="показывает статус бота (если не показывает, значит бот не жив)",
        inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.slash_command()
@commands.has_any_role(1123765409062060093)
async def modhelp(self, interaction):
    embed = disnake.Embed(title="SpeedwagonBot 1.3",
                          description="by Marshall131",
                          color=disnake.Color.yellow())
    embed.add_field(name="Commands:", value=" ", inline=False)
    embed.add_field(name="Префикс:", value="$ и /", inline=False)
    embed.add_field(
        name="/mute",
        value="мутит определённого пользователя, время указвыается в минутах",
        inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.command()
async def status(ctx):
    await ctx.send("Я живой!")


@bot.command()
async def info(ctx):
    await ctx.send(
        "`SpeedwagonBot version 1.3, бот сделан Marshall131. Бот создан на disnake на языке python. Для помощи по командам испольйте /help, либо /modhelp, для обращения к ChatGPT поставьте слово 'Спидвагон' в начале сообщения `"
    )


@bot.slash_command()
async def poshel_nahui(interaction):
    emoji = "<:pizda_tebe:1247390724715053136>"
    await interaction.response.send_message(f"Сам иди нахуй блять{emoji}")


#@bot.slash_command(name="load")
#@commands.has_any_role(1277507742772363294)
#async def load(ctx, extension):
#    bot.load_extension(f"cogs.{extension}")
#    await ctx.send(f"{extension} загружен")

#@bot.slash_command(name="unload")
#@commands.has_any_role(1277507742772363294)
#async def load(ctx, extension):
#    bot.unload_extension(f"cogs.{extension}")
#   await ctx.send(f"{extension} выгружен")

for file in os.listdir("./cogs"):
    if file.endswith(".py"):
        bot.load_extension(f"cogs.{file[:-3]}")

#for file in os.listdir("./nospam"):
#    if file.endswith(".py"):
#        bot.load_extension(f"nospam.{file[:-3]}")  # Добавляем нейросеть антиспама

bot.run(
    "MTI1MzU4ODUwMjA3MTczODQyOA.Gx7YvS.qwBTC2nii5Jxvrx4YxlyL-rW67hFcHL6t6mmvE")
