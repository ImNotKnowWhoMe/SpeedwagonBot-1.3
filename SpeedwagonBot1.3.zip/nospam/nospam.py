import disnake
from disnake.ext import commands
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
from datetime import timedelta

class AntiSpamCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Загружаем модель и токенайзер для антиспам-нейросети
        model_path = "ruspam_model/"
        self.tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_path, local_files_only=True)

    # Функция предсказания на основе нейросети
    def predict(self, text):
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=256)
        with torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits
            predicted_class = torch.argmax(logits, dim=1).item()
        return True if predicted_class == 1 else False

    # Событие, срабатывающее при каждом сообщении
    @commands.Cog.listener()
    async def on_message(self, message):
        # Игнорируем сообщения от самого бота
        if message.author == self.bot.user:
            return

        # Проверяем сообщение на спам
        if self.predict(message.content):
            await message.channel.send(f"{message.author.mention}, спам запрещён! Вы получите мут на 10 минут.")

            # Выдаём тайм-аут (мут) на 10 минут
            try:
                await message.author.timeout(timedelta(minutes=10), reason="Спам.")
                await message.channel.send(f"{message.author.mention} получил тайм-аут на 10 минут.")
            except Exception as e:
                await message.channel.send(f"Не удалось выдать тайм-аут: {str(e)}")
